#!/bin/bash
mysql -u root -pstrikeforcehydra << EOF
use plaintech;
INSERT INTO customer (c_id, c_password, c_email, c_registrationdate) VALUES ('ID','PASSWORD','EMAIL@EMAIL.EMAIL',CURRENT_TIMESTAMP);
EOF
