#!/bin/bash
SPACE=$1

sudo parted /dev/sda unit GB print free | grep 'extended' | tail -n1 | awk {'print $4'}

echo $FREE
echo $SPACE

if [ $SPACE -gt 0 ];
then
	echo "bigger"
else
	echo "smaller"
fi
