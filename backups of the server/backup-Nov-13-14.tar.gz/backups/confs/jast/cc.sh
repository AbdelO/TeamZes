#!/bin/bash

TEST=$(mysql -u root -pstrikeforcehydra -e "USE plaintech; SELECT COUNT(*)FROM customer WHERE c_id = 'ID';")
TEST1="${TEST: -1}"

if [ "$TEST1" -gt "0" ]
then
	echo "1"
else
	echo "0"
fi
