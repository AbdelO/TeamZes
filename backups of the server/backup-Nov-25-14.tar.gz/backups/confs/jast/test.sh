#!/bin/bash
ID=$1
PASSWORD=$2
EMAIL=$3

mysql -u root -pstrikeforcehydra << EOF
use plaintech;
INSERT INTO customer (c_id, c_password, c_email, c_registrationdate) VALUES ('${ID}','${PASSWORD}','${EMAIL}',CURRENT_TIMESTAMP);
EOF
