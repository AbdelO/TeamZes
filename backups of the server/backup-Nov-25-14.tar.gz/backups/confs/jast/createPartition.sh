#!/bin/bash
SPACE=$1	#Variabel 1

FREE="$(sudo parted /dev/sda unit GB print free | grep 'extended' | tail -n1 | awk {'print $4'})"	#Unallocated dskspace

echo $FREE
echo $SPACE

if [ $SPACE -lt ${FREE%??} ];	#Check for free diskspace
then
	echo "true"	#if true, create partition
	echo $(date +%T) "SUCCES. Partion X Created. Size =" $SPACE "GB. " $FREE  "Remaining"  >> partitionLog.txt
else
	echo "false"	#if false, return error
	echo $(date +%T) "FAILED. Partition X FAILED to create. Size requesed =" $SPACE "GB. Space available =" $FREE >> partitionLog.txt
fi	#end if statement
